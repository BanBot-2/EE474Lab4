var _lab4___part_i_i_8ino =
[
    [ "LCD_ADDRESS", "_lab4___part_i_i_8ino.html#aab25150c611eb3bcd9efa6945d1ef7f7", null ],
    [ "LED_PIN", "_lab4___part_i_i_8ino.html#ab4553be4db9860d940f81d7447173b2f", null ],
    [ "PHOTO_PIN", "_lab4___part_i_i_8ino.html#af1dd52694b9686912d499ff32ca40c8f", null ],
    [ "SCL_PIN", "_lab4___part_i_i_8ino.html#a06c967e78bcedcee909a70764f879433", null ],
    [ "SDA_PIN", "_lab4___part_i_i_8ino.html#a526d580d324bce60a3e964066fae77e3", null ],
    [ "isPrime", "_lab4___part_i_i_8ino.html#ac2d541fc721d953b21bddf7f863d6a4b", null ],
    [ "lcd", "_lab4___part_i_i_8ino.html#acd9c0340123358ac852651af80625f1b", null ],
    [ "loop", "_lab4___part_i_i_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "_lab4___part_i_i_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "vTaskAnomaly", "_lab4___part_i_i_8ino.html#ae41fab97fed4a702d291125858e63f0d", null ],
    [ "vTaskLCD", "_lab4___part_i_i_8ino.html#a3d8bc60e04295c59e0299e9bbfbf66fa", null ],
    [ "vTaskLight", "_lab4___part_i_i_8ino.html#a69e1acb7e38c294855cc25e5676f8c37", null ],
    [ "vTaskPrime", "_lab4___part_i_i_8ino.html#a5fb1eaa1350bdb5ea5613d0159a73eea", null ],
    [ "average", "_lab4___part_i_i_8ino.html#a28950bb39985d4589b8c34831cc1a4e7", null ],
    [ "changed", "_lab4___part_i_i_8ino.html#a1e97de47a8a461255d7e9130c8fcdee2", null ],
    [ "light", "_lab4___part_i_i_8ino.html#a840d98f11adfbaeeb77afa32ceb0e278", null ],
    [ "xLightSemaphore", "_lab4___part_i_i_8ino.html#af5d8d129f00b141c8e7fffd4b5534dea", null ]
];