var searchData=
[
  ['scheduletasks_0',['scheduleTasks',['../_lab4___part_i_8ino.html#a4ea4585de20507653ce66667bb133d6f',1,'Lab4_PartI.ino']]],
  ['setup_1',['setup',['../_lab4___part_i_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;Lab4_PartI.ino'],['../_lab4___part_i_i_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;Lab4_PartII.ino']]]
];
