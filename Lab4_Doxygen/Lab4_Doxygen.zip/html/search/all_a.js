var searchData=
[
  ['timeslice_0',['timeSlice',['../_lab4___part_i_8ino.html#aae032876a7fd986bbdd7c9f185050c3e',1,'Lab4_PartI.ino']]]
];
