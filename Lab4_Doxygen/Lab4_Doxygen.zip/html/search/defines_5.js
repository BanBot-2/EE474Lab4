var searchData=
[
  ['scl_5fpin_0',['SCL_PIN',['../_lab4___part_i_i_8ino.html#a06c967e78bcedcee909a70764f879433',1,'Lab4_PartII.ino']]],
  ['sda_5fpin_1',['SDA_PIN',['../_lab4___part_i_i_8ino.html#a526d580d324bce60a3e964066fae77e3',1,'Lab4_PartII.ino']]]
];
